//
// Created by ascend on 2021/5/13.
//

#include <pthread.h>
#include <chrono>
#include <fstream>
#include <iostream>
#include <memory>
#include <sstream>
#include <string>

#include <boost/filesystem.hpp>

#include <nav_msgs/Odometry.h>
#include <ros/ros.h>
#include <sensor_msgs/Imu.h>
#include <sensor_msgs/PointCloud2.h>
#include <std_msgs/Bool.h>
#include <std_msgs/Float32.h>
#include <std_msgs/String.h>
#include <velodyne_pcl/point_types.h>
#include <velodyne_pointcloud/rawdata.h>

#include <geometry_msgs/PoseWithCovarianceStamped.h>
#include <geometry_msgs/TwistStamped.h>

#include <tf/tf.h>
#include <tf/transform_broadcaster.h>
#include <tf/transform_datatypes.h>
#include <tf/transform_listener.h>

#include <pcl/io/io.h>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <pcl_conversions/pcl_conversions.h>
#include <pcl/filters/passthrough.h>

#include <ndt_cpu/NormalDistributionsTransform.h>
#include <pcl/registration/ndt.h>

#ifdef CUDA_FOUND
#include <ndt_gpu/NormalDistributionsTransform.h>
#endif

#ifdef USE_PCL_OPENMP

#include <pclomp/ndt_omp.h>

#endif

#include <pcl_ros/point_cloud.h>
#include <pcl_ros/transforms.h>

#include <std_srvs/Empty.h>

#include<random>

using namespace std;

ros::Publisher initial_pose_pub;
bool relocalizing = false;
float fitnessScore;

struct point2d {
    float x;
    float y;
};

struct RobotPose {
    float x;
    float y;
    float yaw;
};

static vector<point2d> pointList = {
        point2d{1, 1},
        point2d{2, 2},
        point2d{3, 3},
        point2d{4, 4}};

vector<RobotPose> generatePose() {
    
    int NUM = 10;
    vector<RobotPose> poseList;
    point2d a, b;

    for (int pointId = 0; pointId < pointList.size() - 1; pointId++) {
        a = pointList[pointId];
        b = pointList[pointId + 1];

        double dist_x = b.x - a.x;
        double dist_y = b.y - a.y;

        for (int i = 0; i < NUM; i++) {
            RobotPose pose;
            pose.x = a.x + dist_x / NUM * i;
            pose.y = a.y + dist_y / NUM * i;

            ROS_INFO("generating..... :(%f,%f)", pose.x, pose.y);
        
            for (double yaw = -3.14; yaw <= 3.14; yaw += 0.0436) {
                pose.yaw = yaw;
                poseList.push_back(pose);
            }
        }

    }

    return poseList;
}

static void fitnessCb(const std_msgs::Float32 fitnessScore_) {
    fitnessScore = fitnessScore_.data;
}

bool relocalizeCb(std_srvs::EmptyRequest &req, std_srvs::EmptyResponse &res) {
    relocalizing = true;
    ROS_INFO("relocalizing .......");

//    // for example current posee
//
//    default_random_engine e(time(0));
//    uniform_real_distribution<double> u(-3.0, 3.0);
//    for (int i = 0; i < 10; ++i)
//        cout << u(e) << endl;

    vector<RobotPose> poseList;
    poseList = generatePose();

    for (int poseId = 0; poseId < poseList.size(); poseId++) {

        geometry_msgs::PoseWithCovarianceStamped pose_msg;

        pose_msg.header.stamp = ros::Time::now();
        pose_msg.header.frame_id = "map";
        pose_msg.pose.pose.position.x = poseList[poseId].x;
        pose_msg.pose.pose.position.y = poseList[poseId].y;
        pose_msg.pose.covariance[0] = 0.25;
        pose_msg.pose.covariance[6 * 1 + 1] = 0.25;
        pose_msg.pose.covariance[6 * 5 + 5] = 0.06853891945200942;
        pose_msg.pose.pose.orientation.z = sin(poseList[poseId].yaw / 2);
        pose_msg.pose.pose.orientation.w = cos(poseList[poseId].yaw / 2);

        initial_pose_pub.publish(pose_msg);
        ROS_INFO("Setting to :(%f,%f,%f)", poseList[poseId].x, poseList[poseId].y, poseList[poseId].yaw);
    }

    relocalizing = false;
    return true;
}

int main(int argc, char **argv) {
    ros::init(argc, argv, "global_localizer");
    ros::NodeHandle nh;
    ros::NodeHandle private_nh("~");

    ros::ServiceServer relocalize_server = nh.advertiseService("/relocalize", relocalizeCb);
    ros::Subscriber fitness_sub = nh.subscribe("/ndt_fitness_score", 10, fitnessCb);
    initial_pose_pub = nh.advertise<geometry_msgs::PoseWithCovarianceStamped>("/initialpose", 10);

    ros::spin();
}